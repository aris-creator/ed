<?php
/**
 * Template Name: Alternate Sidebar Page
 *
 * @package Edin
 */

get_header(); ?>

<?php get_template_part( 'page' ); ?>